# angular-muse

Connect to the Muse EEG Headset (2016 Edition) through Web Bluetooth

[Live Demo](https://muse-eeg-app.firebaseapp.com)

Copyright (C) 2017, Alex Castillo and Uri Shaked. 
Code released under the MIT license.

![muse-eeg-app screen shot](screenshot.png)
