/// <reference types="jest" />

import 'jest-preset-angular';
